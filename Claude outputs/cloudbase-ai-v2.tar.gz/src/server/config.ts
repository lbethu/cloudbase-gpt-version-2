import "server-only";
import path from "node:path";

/**
 * Centralized server configuration. Every environment variable the platform
 * reads is declared here — nothing else in the codebase touches process.env.
 * Secrets never leave the server.
 */

const bool = (value: string | undefined, fallback = false) =>
  value === undefined ? fallback : ["1", "true", "yes", "on"].includes(value.toLowerCase());

const list = (value: string | undefined) =>
  (value ?? "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);

export type AuthMode = "dev" | "entra" | "none";
export type AiProviderName = "disabled" | "openai" | "azure-openai" | "anthropic" | "gemini";

export interface CloudBaseConfig {
  env: "development" | "production" | "test";
  contentDir: string;
  sourceDocumentsDir: string;
  auditDir: string;
  auth: {
    mode: AuthMode;
    dev: { subject: string; name: string; email: string; roles: string[]; teams: string[] };
    /** JSON map of Entra group object ids → CloudBase role ids. */
    entraGroupRoleMap: Record<string, string>;
    entraGroupTeamMap: Record<string, string>;
    tenantId: string;
  };
  ai: {
    provider: AiProviderName;
    model: string;
    apiKey: string;
    baseUrl: string;
    azureDeployment: string;
  };
  search: { provider: "lexical" | "hybrid" };
  features: { legacyPrototype: boolean };
  drive: { configured: boolean };
}

const parseJsonMap = (value: string | undefined): Record<string, string> => {
  if (!value) return {};
  try {
    const parsed: unknown = JSON.parse(value);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return Object.fromEntries(Object.entries(parsed as Record<string, unknown>).map(([k, v]) => [k, String(v)]));
    }
  } catch {
    /* fall through */
  }
  return {};
};

let cached: CloudBaseConfig | null = null;

export function getConfig(): CloudBaseConfig {
  if (cached) return cached;
  const env = (process.env.NODE_ENV as CloudBaseConfig["env"]) ?? "development";
  const requestedMode = (process.env.CLOUDBASE_AUTH_MODE as AuthMode | undefined) ?? (env === "production" ? "none" : "dev");
  // Never allow the development identity provider in production builds.
  const mode: AuthMode = env === "production" && requestedMode === "dev" ? "none" : requestedMode;

  const rootDir = process.cwd();
  cached = {
    env,
    contentDir: process.env.CLOUDBASE_CONTENT_DIR ?? path.join(rootDir, "content"),
    sourceDocumentsDir: process.env.CLOUDBASE_SOURCE_DOCUMENTS_DIR ?? path.join(rootDir, "source-documents"),
    auditDir: process.env.CLOUDBASE_AUDIT_DIR ?? path.join(rootDir, "var", "audit"),
    auth: {
      mode,
      dev: {
        subject: process.env.CLOUDBASE_DEV_USER_SUBJECT ?? "dev-user",
        name: process.env.CLOUDBASE_DEV_USER_NAME ?? "Development User",
        email: process.env.CLOUDBASE_DEV_USER_EMAIL ?? "dev@cloudpoint.local",
        roles: list(process.env.CLOUDBASE_DEV_USER_ROLES ?? "employee,contributor,reviewer,approver,ai-steward,admin"),
        teams: list(process.env.CLOUDBASE_DEV_USER_TEAMS ?? "company-wide,ai-automation"),
      },
      entraGroupRoleMap: parseJsonMap(process.env.CLOUDBASE_ENTRA_GROUP_ROLE_MAP),
      entraGroupTeamMap: parseJsonMap(process.env.CLOUDBASE_ENTRA_GROUP_TEAM_MAP),
      tenantId: process.env.CLOUDBASE_TENANT_ID ?? "cloudpoint",
    },
    ai: {
      provider: (process.env.CLOUDBASE_AI_PROVIDER as AiProviderName | undefined) ?? "disabled",
      model: process.env.CLOUDBASE_AI_MODEL ?? "",
      apiKey: process.env.CLOUDBASE_AI_API_KEY ?? "",
      baseUrl: process.env.CLOUDBASE_AI_BASE_URL ?? "",
      azureDeployment: process.env.CLOUDBASE_AI_AZURE_DEPLOYMENT ?? "",
    },
    search: { provider: (process.env.CLOUDBASE_SEARCH_PROVIDER as "lexical" | "hybrid" | undefined) ?? "lexical" },
    features: { legacyPrototype: bool(process.env.CLOUDBASE_ENABLE_LEGACY_PROTOTYPE, env !== "production") },
    drive: { configured: Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY) },
  };
  return cached;
}

/** Test helper — resets the cached config after env changes. */
export function resetConfigForTests() {
  cached = null;
}
