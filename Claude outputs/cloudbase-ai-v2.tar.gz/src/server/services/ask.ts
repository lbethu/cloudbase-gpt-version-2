import "server-only";
import type { ContentType, KnowledgeItem } from "@/domain";
import type { Identity } from "@/server/auth/identity";
import { getAiProvider } from "@/server/ai/adapters";
import { getRepositories } from "@/server/repositories";
import { tokenize } from "@/server/search/lexical";
import { recordAudit } from "./audit";
import { askSystemPrompt, buildGovernedAnswer, latest, validateModelAnswer, type AskAnswer, type AskSource } from "./ask-core";
import { relatedTo } from "./relationships";
import { permittedItems, searchKnowledge } from "./search";

const GOVERNED_STATUSES = new Set(["approved", "published", "operational", "Approved", "Published"]);

/** Best passage from an item for the question: SOP chunk if available, else summary/body excerpt. */
function bestPassage(item: KnowledgeItem, question: string): { passage: string; section?: string } {
  const repos = getRepositories();
  const terms = tokenize(question);
  if (item.ref.type === "sop") {
    const sop = repos.sops.get(item.ref.id);
    const chunks = sop?.versions.flatMap((v) => (v.importedContentId ? (repos.sops.importedContent(v.importedContentId)?.chunks ?? []) : [])) ?? [];
    let best: { score: number; chunk: (typeof chunks)[number] } | null = null;
    for (const chunk of chunks) {
      const text = `${chunk.section} ${chunk.content} ${chunk.keywords.join(" ")}`.toLowerCase();
      const score = terms.reduce((acc, t) => acc + (text.includes(t) ? 1 : 0), 0);
      if (!best || score > best.score) best = { score, chunk };
    }
    if (best) return { passage: best.chunk.content.slice(0, 600), section: best.chunk.section };
  }
  const body = item.body || item.summary;
  const lower = body.toLowerCase();
  const at = terms.map((t) => lower.indexOf(t)).filter((i) => i >= 0).sort((a, b) => a - b)[0] ?? 0;
  const start = Math.max(0, lower.lastIndexOf("\n", at) + 1);
  return { passage: body.slice(start, start + 500).replace(/\s+/g, " ").trim() || item.summary };
}

export async function askCloudBase(identity: Identity, question: string): Promise<AskAnswer> {
  const q = question.trim().slice(0, 500);
  const { hits } = await searchKnowledge(identity, { q, limit: 8 });
  const permitted = permittedItems(identity);
  const byKey = new Map(permitted.map((i) => [`${i.ref.type}:${i.ref.id}`, i]));

  const sources: AskSource[] = hits.slice(0, 6).map((hit, index) => {
    const full = byKey.get(`${hit.item.ref.type}:${hit.item.ref.id}`)!;
    const { passage, section } = bestPassage(full, q);
    return {
      index,
      ref: hit.item.ref,
      title: hit.item.title,
      url: hit.item.url,
      status: hit.item.status,
      governed: GOVERNED_STATUSES.has(hit.item.status),
      passage,
      section,
      updatedAt: hit.item.updatedAt,
      owningTeam: hit.item.owningTeam,
    };
  });

  // Related knowledge: other hits grouped by type + declared relationships of the top source.
  const related: AskAnswer["related"] = {};
  const push = (type: ContentType, entry: { ref: KnowledgeItem["ref"]; title: string; url: string; status: string }) => {
    const list = (related[type] ??= []);
    if (!list.some((e) => e.ref.id === entry.ref.id)) list.push(entry);
  };
  for (const hit of hits.slice(0, 12)) push(hit.item.ref.type, { ref: hit.item.ref, title: hit.item.title, url: hit.item.url, status: hit.item.status });
  if (sources[0]) {
    for (const group of relatedTo(getRepositories(), sources[0].ref, permitted)) {
      for (const e of group.entries) push(group.type, { ref: e.ref, title: e.title, url: e.url, status: e.status });
    }
  }

  const provider = getAiProvider();
  recordAudit({ actor: identity.subject, action: "ask.query", outcome: "allowed", detail: { length: q.length, sources: sources.length, provider: provider.name } });

  if (!provider.enabled || sources.length === 0) return buildGovernedAnswer(q, sources, related);

  try {
    const sourceBlock = sources.map((s) => `[${s.index}] (${s.ref.type}${s.governed ? ", approved" : ", NOT yet approved"}) ${s.title}${s.section ? ` — ${s.section}` : ""}\n${s.passage}`).join("\n\n");
    const result = await provider.complete({
      json: true,
      messages: [
        { role: "system", content: askSystemPrompt() },
        { role: "user", content: `Question: ${q}\n\nSources:\n${sourceBlock}` },
      ],
    });
    const statements = validateModelAnswer(result.text, sources);
    if (!statements) {
      const fallback = buildGovernedAnswer(q, sources, related);
      fallback.notices.unshift("The AI response failed validation and was discarded; showing governed retrieval instead.");
      return fallback;
    }
    const notices: string[] = [];
    if (sources.some((s) => !s.governed)) notices.push("One or more cited sources are not yet approved. Treat them as imported reference material until the owner confirms them.");
    return { question: q, mode: "ai-grounded", statements, sources, related, lastUpdated: latest(sources), notices, provider: `${result.provider}/${result.model}` };
  } catch (error) {
    recordAudit({ actor: identity.subject, action: "ask.provider-error", outcome: "error", detail: { message: error instanceof Error ? error.message : "unknown" } });
    const fallback = buildGovernedAnswer(q, sources, related);
    fallback.notices.unshift("The AI provider was unavailable; showing governed retrieval instead.");
    return fallback;
  }
}
