import {
  Bot,
  BookOpen,
  Briefcase,
  CheckSquare,
  FileCode2,
  FlaskConical,
  Home,
  Layers,
  Orbit,
  Scale,
  ScrollText,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
  Workflow,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  home: Home,
  sparkles: Sparkles,
  search: Search,
  users: Users,
  book: BookOpen,
  "file-code": FileCode2,
  flask: FlaskConical,
  orbit: Orbit,
  layers: Layers,
  briefcase: Briefcase,
  scale: Scale,
  bot: Bot,
  workflow: Workflow,
  "check-square": CheckSquare,
  shield: ShieldCheck,
  scroll: ScrollText,
};

export function Icon({ name, size = 16 }: { name: string; size?: number }) {
  const Component = ICONS[name] ?? Layers;
  return <Component size={size} aria-hidden="true" />;
}
