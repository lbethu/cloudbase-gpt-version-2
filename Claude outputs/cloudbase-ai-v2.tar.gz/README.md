# CloudBase AI

**Cloudpoint Knowledge & Intelligence Hub** — one internal platform to discover Cloudpoint knowledge, SOPs, R&D (CROS), capabilities, project references, AI copilots, automations and technical guidance, with source attribution, ownership, versions and governed human approval.

This is a production-oriented internal operating platform, not a marketing site or a chatbot. AI may search, summarize, connect, recommend and draft; it never approves SOPs, publishes policy, promotes R&D maturity or creates organizational truth.

## What is here

| Area | Route | Notes |
| --- | --- | --- |
| Home | `/` | Domains, recommendations, recent updates, active R&D, copilots, review attention |
| Universal search | `/search`, `⌘K` | Permission-scoped lexical search with type/team facets |
| Ask CloudBase | `/ask` | Governed answers: FACT / SUPPORTED_INFERENCE / ASSUMPTION / UNKNOWN with citations |
| Team Workspaces | `/teams` | Teams are registry data; knowledge is shared by relationship, never duplicated |
| SOP Library | `/sops` | Governed lifecycle (draft → review → approved → superseded → historical), versions, protected source files |
| Documentation | `/docs` | Markdown + frontmatter, highlighted code, copy buttons, TOC |
| Research | `/research` | Research library + 7 templates, CROS-linked |
| CROS | `/cros` | Read-only R&D operating system: projects, capabilities, clusters, ideas, evaluations, evidence, experiments, decisions, portfolio, CROS Copilot entry |
| Capabilities | `/capabilities` | Project vs. capability, maturity R0–R7, clusters |
| Project References | `/projects` | Reference library + Project Reference Assistant |
| RFP Intelligence | `/rfp` | Records + “How we build an RFP Evaluation Assistant” |
| Copilots | `/copilots` | Registry, Creation Center, Engineering Standard |
| Automations | `/automations` | Library, proposal intake, Engineering Standard |
| Governance | `/governance/*` | Review queue, admin center, audit history |

Legacy prototype (fictional review corpus) remains at `/legacy` and `/presentation` behind `CLOUDBASE_ENABLE_LEGACY_PROTOTYPE` (off in production).

## Architecture

```
src/app/(platform)        routes — server components, permission-aware
src/components            shell (sidebar, ⌘K palette), ui primitives, detail-page standard
src/domain                Zod schemas for every governed entity
src/server/auth           IdentityProvider seam (dev · Entra ID via authenticating proxy)
src/server/authz          default-deny, explicit-deny precedence, classification checks
src/server/repositories   interfaces + file registry implementation (PostgreSQL later)
src/server/services       search, ask, relationships, reviews, files, audit, markdown
src/server/search         SearchProvider — lexical today, hybrid/vector seam
src/server/ai             AiProvider — disabled by default; OpenAI / Azure OpenAI / Anthropic / Gemini adapters
content/registry          teams, roles, sops/*, cros/*, copilots, automations, relationships, synonyms
content/docs              governed documentation (markdown + frontmatter)
content/templates         research templates
content/knowledge         imported, source-backed SOP text
source-documents/         original SOP files — served ONLY via /api/files/{id} with authorization + audit
```

See `docs/cloudbase-implementation-plan.md` for the audit, decisions and phase plan, and `/docs/cloudbase-architecture` inside the app.

## Run

```bash
npm install
cp .env.example .env.local      # dev identity is enabled by default outside production
npm run dev                     # http://localhost:3000
```

Quality gates:

```bash
npm run typecheck
npm test
npm run build
npm run verify                  # all three
```

## Governance rules baked in

- **Default deny.** Every page, API route and file download is authorized server-side against `content/registry/roles.yaml`. Hidden links are not the control.
- **Permission-scoped retrieval.** Search, Ask CloudBase and related-content panels only ever see items the viewer may read.
- **No fabricated data.** No fake SOPs, employees, projects, clients or metrics. Empty states are designed. Imported SOPs enter as *in review*; nothing is approved until an approver records it.
- **CROS is authoritative.** CloudBase reads the CROS registry; maturity is never inferred. Relationships implied by naming are marked *proposed* until confirmed.
- **Audit.** File access, Ask queries (metadata only), denied authorizations and provider errors are appended to `var/audit/`.
- **Versioned knowledge.** SOP history is never overwritten; a new version supersedes the old one.

## Adding knowledge

- Team: add to `content/registry/teams.yaml`.
- SOP: add `content/registry/sops/<id>.yaml` (or use *Create SOP draft* in the app to generate one).
- Documentation: add markdown with frontmatter under `content/docs/<domain>/`.
- Relationship: add a line to `content/registry/relationships.yaml`.
- Copilot / automation / project reference / research / RFP record: add to the matching registry folder.

Every file is validated on load; a malformed record fails with the file and field named.

## Identity in production

Run behind an authenticating proxy (Azure App Service Easy Auth or equivalent) with `CLOUDBASE_AUTH_MODE=entra`. The proxy must strip inbound `x-ms-client-principal`. Map Entra groups/app roles to CloudBase roles and teams with `CLOUDBASE_ENTRA_GROUP_ROLE_MAP` / `CLOUDBASE_ENTRA_GROUP_TEAM_MAP`. The development identity provider is refused in production builds.

## Google Drive live search (optional)

Preserved from the prototype; requires `knowledge.read` and a service account — see `docs/google-drive-integration.md`.
